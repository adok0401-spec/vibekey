package com.vibekeys

import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowInsets
import android.view.inputmethod.EditorInfo
import android.widget.LinearLayout
import android.widget.TextView

class KeyboardService : InputMethodService() {

    private enum class Mode { EN, RU, SYM }
    private enum class Style { NORMAL, FUNC, ACCENT }

    private class Key(
        val label: String,
        val weight: Float = 1f,
        val style: Style = Style.NORMAL,
        val repeat: Boolean = false,
        val action: () -> Unit
    )

    private var mode = Mode.EN
    private var shift = false
    private var caps = false
    private var lastShiftTap = 0L
    private var root: LinearLayout? = null
    private val handler = Handler(Looper.getMainLooper())

    private val en = listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")
    private val ru = listOf("йцукенгшщзхъ", "фывапролджэ", "ячсмитьбю")
    private val sym = listOf("@#$%&-+()/", "*\"':;!?~`|", "=\\<>{}[]^_")

    // ---------- lifecycle ----------

    override fun onCreateInputView(): View {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(3), dp(6), dp(3), dp(6))
        }
        // Keep keys above the gesture/nav bar on Android 15+ edge-to-edge
        r.setOnApplyWindowInsetsListener { v, insets ->
            val bottom = if (Build.VERSION.SDK_INT >= 30)
                insets.getInsets(WindowInsets.Type.navigationBars()).bottom else 0
            v.setPadding(dp(3), dp(6), dp(3), dp(6) + bottom)
            insets
        }
        root = r
        render()
        return r
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        shift = false; caps = false
        // number/phone fields -> symbols
        val cls = (info?.inputType ?: 0) and android.text.InputType.TYPE_MASK_CLASS
        mode = if (cls == android.text.InputType.TYPE_CLASS_NUMBER ||
            cls == android.text.InputType.TYPE_CLASS_PHONE) Mode.SYM
        else if (mode == Mode.SYM) Mode.EN else mode
        render()
    }

    // ---------- theme ----------

    private val dark get() =
        (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
    private val bg get() = if (dark) 0xFF1B1B1D.toInt() else 0xFFE8E9ED.toInt()
    private val keyColor get() = if (dark) 0xFF3B3B3F.toInt() else 0xFFFFFFFF.toInt()
    private val funcColor get() = if (dark) 0xFF2A2A2D.toInt() else 0xFFCFD1D8.toInt()
    private val accentColor get() = 0xFF3E91FF.toInt()
    private val textColor get() = if (dark) Color.WHITE else Color.BLACK

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ---------- layout ----------

    private fun render() {
        val r = root ?: return
        r.setBackgroundColor(bg)
        r.removeAllViews()

        // number row
        r.addView(row("1234567890".map { c -> charKey(c.toString(), false) }))

        when (mode) {
            Mode.EN, Mode.RU -> {
                val rows = if (mode == Mode.EN) en else ru
                r.addView(row(rows[0].map { charKey(it.toString()) }))
                r.addView(row(rows[1].map { charKey(it.toString()) }, sidePad = 0.35f))
                val third = mutableListOf<Key>()
                third += Key(if (caps) "⇪" else "⇧", 1.5f, Style.FUNC) { onShift() }
                third += rows[2].map { charKey(it.toString()) }
                third += Key("⌫", 1.5f, Style.FUNC, repeat = true) { backspace() }
                r.addView(row(third))
                r.addView(row(bottomRow(toSym = true)))
            }
            Mode.SYM -> {
                r.addView(row(sym[0].map { charKey(it.toString(), false) }))
                r.addView(row(sym[1].map { charKey(it.toString(), false) }))
                val third = mutableListOf<Key>()
                third += Key("ABC", 1.5f, Style.FUNC) { mode = Mode.EN; render() }
                third += sym[2].map { charKey(it.toString(), false) }
                third += Key("⌫", 1.5f, Style.FUNC, repeat = true) { backspace() }
                r.addView(row(third))
                r.addView(row(bottomRow(toSym = false)))
            }
        }
    }

    private fun bottomRow(toSym: Boolean): List<Key> = listOf(
        if (toSym) Key("?123", 1.5f, Style.FUNC) { mode = Mode.SYM; render() }
        else Key("ABC", 1.5f, Style.FUNC) { mode = Mode.EN; render() },
        Key("🌐", 1f, Style.FUNC) { mode = if (mode == Mode.EN) Mode.RU else Mode.EN; render() },
        Key(",", 1f) { commit(",") },
        Key(if (mode == Mode.RU) "Русский" else "English", 4.5f) { commit(" ") },
        Key(".", 1f) { commit(".") },
        Key("⏎", 1.5f, Style.ACCENT) { enter() }
    )

    private fun charKey(c: String, letter: Boolean = true): Key {
        val label = if (letter && shift) c.uppercase() else c
        return Key(label) { commit(label) }
    }

    private fun row(keys: List<Key>, sidePad: Float = 0f): LinearLayout {
        val line = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(52))
        }
        if (sidePad > 0f) line.addView(spacer(sidePad))
        keys.forEach { line.addView(keyView(it)) }
        if (sidePad > 0f) line.addView(spacer(sidePad))
        return line
    }

    private fun spacer(w: Float) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(0, 1, w)
    }

    private fun keyView(k: Key): TextView {
        fun shape(color: Int) = GradientDrawable().apply {
            cornerRadius = dp(8).toFloat()
            setColor(color)
        }
        val base = when (k.style) {
            Style.NORMAL -> keyColor
            Style.FUNC -> funcColor
            Style.ACCENT -> accentColor
        }
        val pressed = if (dark) 0xFF5A5A60.toInt() else 0xFFB8BBC4.toInt()

        val tv = TextView(this)
        tv.text = k.label
        tv.gravity = Gravity.CENTER
        tv.textSize = if (k.label.length > 2) 14f else 20f
        tv.setTextColor(if (k.style == Style.ACCENT) Color.WHITE else textColor)
        tv.background = shape(base)
        tv.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, k.weight)
            .apply { setMargins(dp(2), dp(3), dp(2), dp(3)) }

        val repeater = object : Runnable {
            override fun run() { k.action(); handler.postDelayed(this, 50) }
        }
        tv.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    tv.background = shape(pressed)
                    v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    k.action()
                    if (k.repeat) handler.postDelayed(repeater, 400)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(repeater)
                    tv.background = shape(base)
                }
            }
            true
        }
        return tv
    }

    // ---------- actions ----------

    private fun commit(text: String) {
        currentInputConnection?.commitText(text, 1)
        if (shift && !caps) { shift = false; render() }
    }

    private fun backspace() {
        sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
    }

    private fun onShift() {
        val now = System.currentTimeMillis()
        if (shift && now - lastShiftTap < 400) {
            caps = true
        } else {
            shift = !shift
            caps = false
        }
        lastShiftTap = now
        render()
    }

    private fun enter() {
        val ei = currentInputEditorInfo
        val action = (ei?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
        val noAction = ((ei?.imeOptions ?: 0) and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (ei == null || noAction ||
            action == EditorInfo.IME_ACTION_NONE ||
            action == EditorInfo.IME_ACTION_UNSPECIFIED) {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        } else {
            currentInputConnection?.performEditorAction(action)
        }
    }
}
